import React from 'react'

function Home() {
    return (

        <div className='home' > 
         <img src='https://image.freepik.com/free-vector/group-friends-sitting-table-talking-drinking-coffee-tea-tiny-people-friends-meeting-cheer-up-friend-friendship-support-concept-pinkish-coral-bluevector-isolated-illustration_335657-1404.jpg'/>
        </div>
    )
}

export default Home
